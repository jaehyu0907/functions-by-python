import matplotlib.pyplot as plt
import numpy as np

plt.grid(True)
plt.show()